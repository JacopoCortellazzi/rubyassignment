class Person

	attr_accessor :name, :age
	
	def initialize(name, age = 0)
		@name = name
		@age = age
	end
end
